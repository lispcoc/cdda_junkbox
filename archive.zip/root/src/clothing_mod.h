#pragma once
#ifndef CLOTHING_MOD_H
#define CLOTHING_MOD_H

#include <stddef.h>
#include <string>
#include <vector>

#include "type_id.h"
#include "string_id.h"

class JsonObject;

struct clothing_mod {
    void load( JsonObject &jo, const std::string &src );

    clothing_mod_id id;
    bool was_loaded = false;

    std::string flag;
    std::string item;
    std::string implement_prompt;
    std::string destroy_prompt;

    static size_t count();
};

namespace clothing_mods
{

void load( JsonObject &jo, const std::string &src );
void reset();

const std::vector<clothing_mod> &get_all();

} // namespace clothing_mods

#endif
