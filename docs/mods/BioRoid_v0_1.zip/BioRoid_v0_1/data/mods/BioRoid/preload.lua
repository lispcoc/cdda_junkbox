BioRoid = {}
BioRoid.player_act_counter = nil
BioRoid.callback = nil
BioRoid.ignore_enemy = false
BioRoid.item = nil
BioRoid.properties = {}

function BioRoid.convert_creature_to_npc(creature)
    local npc
    if creature then
        if creature:is_npc() then
            npc = debug.setmetatable(creature, debug.getmetatable(player))
            return npc
        end
    end
    return nil
end

function BioRoid.get_corpse(p)
    for delta_x = -1, 1 do
        for delta_y = -1, 1 do
            local tpoint = tripoint(p.x + delta_x, p.y + delta_y, p.z)
            local stack = map:i_at(tpoint)
            local iter = stack:cppbegin()
            while iter ~= stack:cppend() and not corpse do
                local tmp = iter:elem()
                if tmp:is_corpse() then
                    if tmp:get_mtype():get_meat_itype() == "human_flesh" then
                        return tmp, tpoint
                    end
                end
                iter:inc()
            end
        end
    end
    return nil, nil
end

function BioRoid.iuse_bioroid_kit(item, active)
    local p = player:pos()
    local delta_x
    local delta_y
    local corpse, tpoint = BioRoid.get_corpse(p)
    if corpse == nil then
        game.add_msg("周囲に死体がありません！ 改造する死体は床に置いてください。")
        return
    end
    
    BioRoid.properties["gender"] = item:get_property_string("gender")
    BioRoid.properties["bioroid_type"] = item:get_property_string("type")
    -- 後でアイテムを消す用。
    BioRoid.properties["typeid"] = item:typeId() -- itemはこの関数内でしか使えないので、itypeのコピーを取る
    BioRoid.properties["corpse"] = corpse
    BioRoid.properties["corpse_tpoint"] = tpoint
    BioRoid.ignore_enemy = false
    --
    -- 作業開始(時間は30分)
    BioRoid.player_act_counter = 300
    BioRoid.callback = BioRoid.working
    player:set_moves(-1000)
end

function BioRoid.working()
    local p = player:pos()
    local bioroid_type = BioRoid.properties["bioroid_type"]
    local template = npc_template_id(bioroid_type)
    local npc_tpoint = nil
    if BioRoid.player_act_counter % 100 == 0 then
        game.add_msg("作業をしています・・・。")
    end
    -- ターン毎に残り工数を1減らす
    BioRoid.player_act_counter = BioRoid.player_act_counter - 1

    -- 敵が近くにいる場合は警告を出す
    local crit = g:is_hostile_nearby()
    if crit and not BioRoid.ignore_enemy then
        local msg = crit:disp_name() .. "が近くにいます。作業を中止しますか？"
        if game.query_yn(msg) then
            BioRoid.callback = nil
            player:set_moves(0)
            return
        else
            BioRoid.ignore_enemy = true
        end
    end
    crit = g:is_hostile_very_close()
    if crit then
        local msg = crit:disp_name() .. "がすぐ傍まで来ています！作業を中止しますか？"
        if game.query_yn(msg) then
            BioRoid.callback = nil
            player:set_moves(0)
            return
        end
    end

    -- 作業完了時
    if BioRoid.player_act_counter <= 0 then
        for delta_x = -1, 1 do
            for delta_y = -1, 1 do
                local tpoint = tripoint(p.x + delta_x, p.y + delta_y, p.z)
                if not g:critter_at(tpoint) then
                    npc_tpoint = tpoint
                end
            end
        end
        if not npc_tpoint then
            game.add_msg("生体アンドロイドを配置する場所がありません！")
            -- 失敗したらコールバックを削除する
            BioRoid.callback = nil
            player:set_moves(0)
            return
        end
        map:place_npc(npc_tpoint.x, npc_tpoint.y, template)
        -- place_npcした後時間経過させないとNPCが現れないため、on_turn_passedにコールバックを仕掛ける
        BioRoid.callback = BioRoid.finished
        BioRoid.player_act_counter = 50 -- 50ターン経ってもNPCが現れない場合は失敗
    end
    player:set_moves(-1000)
end

function BioRoid.finished()
    local p = player:pos()
    local npc = nil
    local delta_x
    local delta_y
    local item = BioRoid.gen_bioroid_item
    local gender = BioRoid.properties["gender"]
    local found = false
    BioRoid.player_act_counter = BioRoid.player_act_counter - 1
    if BioRoid.player_act_counter <= 0 then
        game.add_msg("エラー！NPCの生成に失敗しました！")
        -- 失敗したらコールバックを削除する
        BioRoid.callback = nil
        player:set_moves(0)
        return
    end
    for delta_x = -20, 20 do
        for delta_y = -20, 20 do
            local tpoint = tripoint(p.x + delta_x, p.y + delta_y, p.z)
            npc = BioRoid.convert_creature_to_npc(g:critter_at(tpoint))
            -- 生成された生体アンドロイドかチェック
            if npc then
                if npc:has_trait(trait_id("BIOROID_BASE")) 
                   and npc:get_value("bioroid_init") ~= "init" then
                    found = true
                end
            end
            if found then
                break
            end
        end
        if found then
            break
        end
    end
    if npc then
        -- データを初期化する
        if gender == "male" then
            npc.male = true
        elseif gender == "female" then
            npc.male = false
        end
        newname = game.string_input_popup("名前を入力してください。", 30, "")
        if newname ~= "" then
            npc.name = newname
        end
        npc:set_value("bioroid_init", "init")
        -- 処理が終わったらコールバックを削除する
        player:set_moves(0)
        BioRoid.callback = nil
        -- アイテムを消費
        local removed = false
        local i = -1
        while not player:i_at(i):is_null() and not removed do
            local tmp = player:i_at(i)
            if tmp:typeId() == BioRoid.properties["typeid"] then
                player:i_rem(i)
                removed = true
            end
            i = i - 1
        end
        i = 0
        while not player:i_at(i):is_null() and not removed do
            local tmp = player:i_at(i)
            if tmp:typeId() == BioRoid.properties["typeid"] then
                player:i_rem(i)
                removed = true
            end
            i = i + 1
        end
        -- 死体を消費
        map:i_rem(BioRoid.properties["corpse_tpoint"], BioRoid.properties["corpse"])
        game.add_msg("生体アンドロイドが動き始めました！")
        return
    end
    player:set_moves(-1000)
end

game.register_iuse("IUSE_BIOROID_KIT", BioRoid.iuse_bioroid_kit)
