###NPC Extention

##概要
NPCに関するあれやこれやのMOD詰め合わせ（予定）です。
今のとこの内容は以下。
- StatsThroughSkills For NPC
- NPC Tweaks

##StatsThroughSkills For NPC
標準MODのStatsThroughSkillsをNPCに適用するMODです。
一分毎にLUAコールバックを呼び出し、プレイヤーを中心とした21x21タイルのNPCに適用します。
(大した処理はしていませんがNPCが増えてくると処理が重くなるかもしれません)

##NPC Tweaks(追加 - NPCの機能拡張)
バニラだとNPCに武術を使わせられない！名前変えたい！
そんな要望に応えるためのアイテムを追加します。
- 名札
  NPC/プレイヤーの名前を変更します。
  製作レベル1で作成可能。
- 学習装置(武術)
  NPCに武術を教えます。対応した武術本を持っている必要あり。
  電子工学レベル4、コンピュータレベル4、機械整備レベル2で作成可能(たぶん)。

##注意
完全にLUAに依存したコードになっているので、バージョンが変わると上手く動かないかもしれません。
一応0.C-7509で動作確認。

##スペシャルサンクス
＠の溜まり場II Cataclysmスレのみなさま

##ライセンス
Creative Commons Attribution ShareAlike 3.0とします。
改変・再配布等ご自由にお願いします。
