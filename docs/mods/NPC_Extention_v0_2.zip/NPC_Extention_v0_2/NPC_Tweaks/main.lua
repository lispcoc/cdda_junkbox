
local MOD = {}

mods["NPC_Tweaks"] = MOD

function MOD.on_minute_passed()
    for delta_x = -10, 10 do
      for delta_y = -10, 10 do
        local point = player:pos()
        point.x = point.x + delta_x
        point.y = point.y + delta_y
        local npc = convert_creature_to_npc(g:critter_at(point))
        if npc then
          -- NPCの戦闘スタイルを復元する
          restore_style_selected(npc)
        end
      end
    end
end

function restore_style_selected(npc)
    local ma_id = npc:get_value("npc_extention_current_ma_style")
    if ma_id and ma_id ~= "" then
      ma = matype_id(ma_id)
      npc.style_selected  = ma
    end
end
